﻿
namespace Modern_Calc
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            this.PnlTitle = new System.Windows.Forms.Panel();
            this.button2 = new System.Windows.Forms.Button();
            this.button1 = new System.Windows.Forms.Button();
            this.btnExit = new System.Windows.Forms.Button();
            this.PanelHistory = new System.Windows.Forms.Panel();
            this.RtBoxDisplayHistory = new System.Windows.Forms.RichTextBox();
            this.BtnClearHis = new System.Windows.Forms.Button();
            this.panel1 = new System.Windows.Forms.Panel();
            this.BtnMenu = new System.Windows.Forms.Button();
            this.btnHistory = new System.Windows.Forms.Button();
            this.TxtDispaly2 = new System.Windows.Forms.TextBox();
            this.TxtDisplay1 = new System.Windows.Forms.TextBox();
            this.EllipseForm = new CtlElipse.CtlEllipseControle();
            this.btnbackspace = new CtlButton.CtlBut();
            this.ctlBut2 = new CtlButton.CtlBut();
            this.ctlBut3 = new CtlButton.CtlBut();
            this.ctlBut4 = new CtlButton.CtlBut();
            this.ctlBut5 = new CtlButton.CtlBut();
            this.ctlBut6 = new CtlButton.CtlBut();
            this.ctlBut7 = new CtlButton.CtlBut();
            this.btnC = new CtlButton.CtlBut();
            this.btnCE = new CtlButton.CtlBut();
            this.btnPercent = new CtlButton.CtlBut();
            this.btndivision = new CtlButton.CtlBut();
            this.btnsquer = new CtlButton.CtlBut();
            this.btnX2 = new CtlButton.CtlBut();
            this.btn1x = new CtlButton.CtlBut();
            this.btnmultiply = new CtlButton.CtlBut();
            this.btnsubtracation = new CtlButton.CtlBut();
            this.btn9 = new CtlButton.CtlBut();
            this.btn6 = new CtlButton.CtlBut();
            this.btn8 = new CtlButton.CtlBut();
            this.btn5 = new CtlButton.CtlBut();
            this.btn7 = new CtlButton.CtlBut();
            this.btn4 = new CtlButton.CtlBut();
            this.btnadd = new CtlButton.CtlBut();
            this.btnEquals = new CtlButton.CtlBut();
            this.btn3 = new CtlButton.CtlBut();
            this.btndesimal = new CtlButton.CtlBut();
            this.btn2 = new CtlButton.CtlBut();
            this.btn0 = new CtlButton.CtlBut();
            this.btn1 = new CtlButton.CtlBut();
            this.btnPm = new CtlButton.CtlBut();
            this.PnlTitle.SuspendLayout();
            this.PanelHistory.SuspendLayout();
            this.panel1.SuspendLayout();
            this.SuspendLayout();
            // 
            // PnlTitle
            // 
            this.PnlTitle.Controls.Add(this.button2);
            this.PnlTitle.Controls.Add(this.button1);
            this.PnlTitle.Controls.Add(this.btnExit);
            this.PnlTitle.Dock = System.Windows.Forms.DockStyle.Top;
            this.PnlTitle.Location = new System.Drawing.Point(0, 0);
            this.PnlTitle.Margin = new System.Windows.Forms.Padding(0);
            this.PnlTitle.Name = "PnlTitle";
            this.PnlTitle.Size = new System.Drawing.Size(368, 40);
            this.PnlTitle.TabIndex = 0;
            // 
            // button2
            // 
            this.button2.FlatAppearance.BorderSize = 0;
            this.button2.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button2.Image = ((System.Drawing.Image)(resources.GetObject("button2.Image")));
            this.button2.Location = new System.Drawing.Point(219, 0);
            this.button2.Margin = new System.Windows.Forms.Padding(0);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(50, 40);
            this.button2.TabIndex = 3;
            this.button2.UseVisualStyleBackColor = true;
            // 
            // button1
            // 
            this.button1.FlatAppearance.BorderSize = 0;
            this.button1.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button1.Image = ((System.Drawing.Image)(resources.GetObject("button1.Image")));
            this.button1.Location = new System.Drawing.Point(274, 0);
            this.button1.Margin = new System.Windows.Forms.Padding(0);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(50, 40);
            this.button1.TabIndex = 2;
            this.button1.UseVisualStyleBackColor = true;
            // 
            // btnExit
            // 
            this.btnExit.Dock = System.Windows.Forms.DockStyle.Right;
            this.btnExit.FlatAppearance.BorderSize = 0;
            this.btnExit.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnExit.Image = ((System.Drawing.Image)(resources.GetObject("btnExit.Image")));
            this.btnExit.Location = new System.Drawing.Point(318, 0);
            this.btnExit.Margin = new System.Windows.Forms.Padding(0);
            this.btnExit.Name = "btnExit";
            this.btnExit.Size = new System.Drawing.Size(50, 40);
            this.btnExit.TabIndex = 0;
            this.btnExit.UseVisualStyleBackColor = true;
            this.btnExit.Click += new System.EventHandler(this.btnExit_Click);
            // 
            // PanelHistory
            // 
            this.PanelHistory.Controls.Add(this.RtBoxDisplayHistory);
            this.PanelHistory.Controls.Add(this.BtnClearHis);
            this.PanelHistory.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.PanelHistory.Location = new System.Drawing.Point(0, 565);
            this.PanelHistory.Margin = new System.Windows.Forms.Padding(0);
            this.PanelHistory.Name = "PanelHistory";
            this.PanelHistory.Size = new System.Drawing.Size(368, 5);
            this.PanelHistory.TabIndex = 1;
            // 
            // RtBoxDisplayHistory
            // 
            this.RtBoxDisplayHistory.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(32)))), ((int)(((byte)(32)))), ((int)(((byte)(32)))));
            this.RtBoxDisplayHistory.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.RtBoxDisplayHistory.Dock = System.Windows.Forms.DockStyle.Fill;
            this.RtBoxDisplayHistory.ForeColor = System.Drawing.Color.Silver;
            this.RtBoxDisplayHistory.Location = new System.Drawing.Point(0, 0);
            this.RtBoxDisplayHistory.Margin = new System.Windows.Forms.Padding(0);
            this.RtBoxDisplayHistory.Name = "RtBoxDisplayHistory";
            this.RtBoxDisplayHistory.ScrollBars = System.Windows.Forms.RichTextBoxScrollBars.Horizontal;
            this.RtBoxDisplayHistory.Size = new System.Drawing.Size(368, 0);
            this.RtBoxDisplayHistory.TabIndex = 5;
            this.RtBoxDisplayHistory.Text = "";
            // 
            // BtnClearHis
            // 
            this.BtnClearHis.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.BtnClearHis.FlatAppearance.BorderSize = 0;
            this.BtnClearHis.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.BtnClearHis.Image = ((System.Drawing.Image)(resources.GetObject("BtnClearHis.Image")));
            this.BtnClearHis.Location = new System.Drawing.Point(0, -35);
            this.BtnClearHis.Margin = new System.Windows.Forms.Padding(0);
            this.BtnClearHis.Name = "BtnClearHis";
            this.BtnClearHis.Size = new System.Drawing.Size(368, 40);
            this.BtnClearHis.TabIndex = 4;
            this.BtnClearHis.UseVisualStyleBackColor = true;
            this.BtnClearHis.Click += new System.EventHandler(this.BtnClearHis_Click);
            // 
            // panel1
            // 
            this.panel1.Controls.Add(this.BtnMenu);
            this.panel1.Controls.Add(this.btnHistory);
            this.panel1.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel1.Location = new System.Drawing.Point(0, 40);
            this.panel1.Margin = new System.Windows.Forms.Padding(0);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(368, 40);
            this.panel1.TabIndex = 2;
            // 
            // BtnMenu
            // 
            this.BtnMenu.Dock = System.Windows.Forms.DockStyle.Left;
            this.BtnMenu.FlatAppearance.BorderSize = 0;
            this.BtnMenu.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.BtnMenu.Image = ((System.Drawing.Image)(resources.GetObject("BtnMenu.Image")));
            this.BtnMenu.Location = new System.Drawing.Point(0, 0);
            this.BtnMenu.Margin = new System.Windows.Forms.Padding(0);
            this.BtnMenu.Name = "BtnMenu";
            this.BtnMenu.Size = new System.Drawing.Size(50, 40);
            this.BtnMenu.TabIndex = 3;
            this.BtnMenu.UseVisualStyleBackColor = true;
            // 
            // btnHistory
            // 
            this.btnHistory.Dock = System.Windows.Forms.DockStyle.Right;
            this.btnHistory.FlatAppearance.BorderSize = 0;
            this.btnHistory.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnHistory.Image = ((System.Drawing.Image)(resources.GetObject("btnHistory.Image")));
            this.btnHistory.Location = new System.Drawing.Point(318, 0);
            this.btnHistory.Margin = new System.Windows.Forms.Padding(0);
            this.btnHistory.Name = "btnHistory";
            this.btnHistory.Size = new System.Drawing.Size(50, 40);
            this.btnHistory.TabIndex = 0;
            this.btnHistory.UseVisualStyleBackColor = true;
            this.btnHistory.Click += new System.EventHandler(this.btnHistory_Click);
            // 
            // TxtDispaly2
            // 
            this.TxtDispaly2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(32)))), ((int)(((byte)(32)))), ((int)(((byte)(32)))));
            this.TxtDispaly2.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.TxtDispaly2.Dock = System.Windows.Forms.DockStyle.Top;
            this.TxtDispaly2.Font = new System.Drawing.Font("Gadugi", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.TxtDispaly2.ForeColor = System.Drawing.Color.Silver;
            this.TxtDispaly2.Location = new System.Drawing.Point(0, 80);
            this.TxtDispaly2.Margin = new System.Windows.Forms.Padding(0);
            this.TxtDispaly2.Multiline = true;
            this.TxtDispaly2.Name = "TxtDispaly2";
            this.TxtDispaly2.Size = new System.Drawing.Size(368, 25);
            this.TxtDispaly2.TabIndex = 3;
            this.TxtDispaly2.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // TxtDisplay1
            // 
            this.TxtDisplay1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(32)))), ((int)(((byte)(32)))), ((int)(((byte)(32)))));
            this.TxtDisplay1.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.TxtDisplay1.Dock = System.Windows.Forms.DockStyle.Top;
            this.TxtDisplay1.Font = new System.Drawing.Font("Gadugi", 30F, System.Drawing.FontStyle.Bold);
            this.TxtDisplay1.ForeColor = System.Drawing.Color.WhiteSmoke;
            this.TxtDisplay1.Location = new System.Drawing.Point(0, 105);
            this.TxtDisplay1.Margin = new System.Windows.Forms.Padding(0);
            this.TxtDisplay1.Multiline = true;
            this.TxtDisplay1.Name = "TxtDisplay1";
            this.TxtDisplay1.Size = new System.Drawing.Size(368, 46);
            this.TxtDisplay1.TabIndex = 4;
            this.TxtDisplay1.Text = "0";
            this.TxtDisplay1.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // EllipseForm
            // 
            this.EllipseForm.CornerRadios = 20;
            this.EllipseForm.TargetControl = this;
            // 
            // btnbackspace
            // 
            this.btnbackspace.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(50)))), ((int)(((byte)(50)))), ((int)(((byte)(50)))));
            this.btnbackspace.BackgroundColor = System.Drawing.Color.FromArgb(((int)(((byte)(50)))), ((int)(((byte)(50)))), ((int)(((byte)(50)))));
            this.btnbackspace.BorderRadios = 20;
            this.btnbackspace.Bordersize = 0;
            this.btnbackspace.FlatAppearance.BorderSize = 0;
            this.btnbackspace.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnbackspace.ForeColor = System.Drawing.Color.White;
            this.btnbackspace.Image = ((System.Drawing.Image)(resources.GetObject("btnbackspace.Image")));
            this.btnbackspace.Location = new System.Drawing.Point(274, 230);
            this.btnbackspace.Margin = new System.Windows.Forms.Padding(0);
            this.btnbackspace.Name = "btnbackspace";
            this.btnbackspace.Size = new System.Drawing.Size(85, 52);
            this.btnbackspace.TabIndex = 5;
            this.btnbackspace.TextColor = System.Drawing.Color.White;
            this.btnbackspace.UseVisualStyleBackColor = false;
            this.btnbackspace.Click += new System.EventHandler(this.btnbackspace_Click);
            // 
            // ctlBut2
            // 
            this.ctlBut2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(32)))), ((int)(((byte)(32)))), ((int)(((byte)(32)))));
            this.ctlBut2.BackgroundColor = System.Drawing.Color.FromArgb(((int)(((byte)(32)))), ((int)(((byte)(32)))), ((int)(((byte)(32)))));
            this.ctlBut2.BorderRadios = 15;
            this.ctlBut2.Bordersize = 0;
            this.ctlBut2.FlatAppearance.BorderSize = 0;
            this.ctlBut2.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.ctlBut2.ForeColor = System.Drawing.Color.DarkGray;
            this.ctlBut2.Location = new System.Drawing.Point(309, 175);
            this.ctlBut2.Margin = new System.Windows.Forms.Padding(0);
            this.ctlBut2.Name = "ctlBut2";
            this.ctlBut2.Size = new System.Drawing.Size(50, 30);
            this.ctlBut2.TabIndex = 5;
            this.ctlBut2.Text = "M~";
            this.ctlBut2.TextColor = System.Drawing.Color.DarkGray;
            this.ctlBut2.UseVisualStyleBackColor = false;
            // 
            // ctlBut3
            // 
            this.ctlBut3.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(32)))), ((int)(((byte)(32)))), ((int)(((byte)(32)))));
            this.ctlBut3.BackgroundColor = System.Drawing.Color.FromArgb(((int)(((byte)(32)))), ((int)(((byte)(32)))), ((int)(((byte)(32)))));
            this.ctlBut3.BorderRadios = 15;
            this.ctlBut3.Bordersize = 0;
            this.ctlBut3.FlatAppearance.BorderSize = 0;
            this.ctlBut3.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.ctlBut3.ForeColor = System.Drawing.Color.DarkGray;
            this.ctlBut3.Location = new System.Drawing.Point(247, 176);
            this.ctlBut3.Margin = new System.Windows.Forms.Padding(0);
            this.ctlBut3.Name = "ctlBut3";
            this.ctlBut3.Size = new System.Drawing.Size(50, 30);
            this.ctlBut3.TabIndex = 5;
            this.ctlBut3.Text = "MS";
            this.ctlBut3.TextColor = System.Drawing.Color.DarkGray;
            this.ctlBut3.UseVisualStyleBackColor = false;
            // 
            // ctlBut4
            // 
            this.ctlBut4.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(32)))), ((int)(((byte)(32)))), ((int)(((byte)(32)))));
            this.ctlBut4.BackgroundColor = System.Drawing.Color.FromArgb(((int)(((byte)(32)))), ((int)(((byte)(32)))), ((int)(((byte)(32)))));
            this.ctlBut4.BorderRadios = 15;
            this.ctlBut4.Bordersize = 0;
            this.ctlBut4.FlatAppearance.BorderSize = 0;
            this.ctlBut4.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.ctlBut4.ForeColor = System.Drawing.Color.DarkGray;
            this.ctlBut4.Location = new System.Drawing.Point(188, 176);
            this.ctlBut4.Margin = new System.Windows.Forms.Padding(0);
            this.ctlBut4.Name = "ctlBut4";
            this.ctlBut4.Size = new System.Drawing.Size(50, 30);
            this.ctlBut4.TabIndex = 5;
            this.ctlBut4.Text = "M-";
            this.ctlBut4.TextColor = System.Drawing.Color.DarkGray;
            this.ctlBut4.UseVisualStyleBackColor = false;
            // 
            // ctlBut5
            // 
            this.ctlBut5.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(32)))), ((int)(((byte)(32)))), ((int)(((byte)(32)))));
            this.ctlBut5.BackgroundColor = System.Drawing.Color.FromArgb(((int)(((byte)(32)))), ((int)(((byte)(32)))), ((int)(((byte)(32)))));
            this.ctlBut5.BorderRadios = 15;
            this.ctlBut5.Bordersize = 0;
            this.ctlBut5.FlatAppearance.BorderSize = 0;
            this.ctlBut5.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.ctlBut5.ForeColor = System.Drawing.Color.DarkGray;
            this.ctlBut5.Location = new System.Drawing.Point(127, 175);
            this.ctlBut5.Margin = new System.Windows.Forms.Padding(0);
            this.ctlBut5.Name = "ctlBut5";
            this.ctlBut5.Size = new System.Drawing.Size(50, 30);
            this.ctlBut5.TabIndex = 5;
            this.ctlBut5.Text = "M+";
            this.ctlBut5.TextColor = System.Drawing.Color.DarkGray;
            this.ctlBut5.UseVisualStyleBackColor = false;
            // 
            // ctlBut6
            // 
            this.ctlBut6.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(32)))), ((int)(((byte)(32)))), ((int)(((byte)(32)))));
            this.ctlBut6.BackgroundColor = System.Drawing.Color.FromArgb(((int)(((byte)(32)))), ((int)(((byte)(32)))), ((int)(((byte)(32)))));
            this.ctlBut6.BorderRadios = 15;
            this.ctlBut6.Bordersize = 0;
            this.ctlBut6.FlatAppearance.BorderSize = 0;
            this.ctlBut6.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.ctlBut6.ForeColor = System.Drawing.Color.DarkGray;
            this.ctlBut6.Location = new System.Drawing.Point(66, 175);
            this.ctlBut6.Margin = new System.Windows.Forms.Padding(0);
            this.ctlBut6.Name = "ctlBut6";
            this.ctlBut6.Size = new System.Drawing.Size(50, 30);
            this.ctlBut6.TabIndex = 5;
            this.ctlBut6.Text = "MR";
            this.ctlBut6.TextColor = System.Drawing.Color.DarkGray;
            this.ctlBut6.UseVisualStyleBackColor = false;
            // 
            // ctlBut7
            // 
            this.ctlBut7.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(32)))), ((int)(((byte)(32)))), ((int)(((byte)(32)))));
            this.ctlBut7.BackgroundColor = System.Drawing.Color.FromArgb(((int)(((byte)(32)))), ((int)(((byte)(32)))), ((int)(((byte)(32)))));
            this.ctlBut7.BorderRadios = 15;
            this.ctlBut7.Bordersize = 0;
            this.ctlBut7.FlatAppearance.BorderSize = 0;
            this.ctlBut7.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.ctlBut7.ForeColor = System.Drawing.Color.DarkGray;
            this.ctlBut7.Location = new System.Drawing.Point(4, 175);
            this.ctlBut7.Margin = new System.Windows.Forms.Padding(0);
            this.ctlBut7.Name = "ctlBut7";
            this.ctlBut7.Size = new System.Drawing.Size(50, 30);
            this.ctlBut7.TabIndex = 5;
            this.ctlBut7.Text = "MC";
            this.ctlBut7.TextColor = System.Drawing.Color.DarkGray;
            this.ctlBut7.UseVisualStyleBackColor = false;
            // 
            // btnC
            // 
            this.btnC.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(50)))), ((int)(((byte)(50)))), ((int)(((byte)(50)))));
            this.btnC.BackgroundColor = System.Drawing.Color.FromArgb(((int)(((byte)(50)))), ((int)(((byte)(50)))), ((int)(((byte)(50)))));
            this.btnC.BorderRadios = 20;
            this.btnC.Bordersize = 0;
            this.btnC.FlatAppearance.BorderSize = 0;
            this.btnC.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnC.ForeColor = System.Drawing.Color.White;
            this.btnC.Location = new System.Drawing.Point(184, 230);
            this.btnC.Margin = new System.Windows.Forms.Padding(0);
            this.btnC.Name = "btnC";
            this.btnC.Size = new System.Drawing.Size(85, 52);
            this.btnC.TabIndex = 5;
            this.btnC.Text = "C";
            this.btnC.TextColor = System.Drawing.Color.White;
            this.btnC.UseVisualStyleBackColor = false;
            this.btnC.Click += new System.EventHandler(this.btnC_Click);
            // 
            // btnCE
            // 
            this.btnCE.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(50)))), ((int)(((byte)(50)))), ((int)(((byte)(50)))));
            this.btnCE.BackgroundColor = System.Drawing.Color.FromArgb(((int)(((byte)(50)))), ((int)(((byte)(50)))), ((int)(((byte)(50)))));
            this.btnCE.BorderRadios = 20;
            this.btnCE.Bordersize = 0;
            this.btnCE.FlatAppearance.BorderSize = 0;
            this.btnCE.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnCE.ForeColor = System.Drawing.Color.White;
            this.btnCE.Location = new System.Drawing.Point(94, 230);
            this.btnCE.Margin = new System.Windows.Forms.Padding(0);
            this.btnCE.Name = "btnCE";
            this.btnCE.Size = new System.Drawing.Size(85, 52);
            this.btnCE.TabIndex = 5;
            this.btnCE.Text = "CE";
            this.btnCE.TextColor = System.Drawing.Color.White;
            this.btnCE.UseVisualStyleBackColor = false;
            this.btnCE.Click += new System.EventHandler(this.btnCE_Click);
            // 
            // btnPercent
            // 
            this.btnPercent.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(50)))), ((int)(((byte)(50)))), ((int)(((byte)(50)))));
            this.btnPercent.BackgroundColor = System.Drawing.Color.FromArgb(((int)(((byte)(50)))), ((int)(((byte)(50)))), ((int)(((byte)(50)))));
            this.btnPercent.BorderRadios = 20;
            this.btnPercent.Bordersize = 0;
            this.btnPercent.FlatAppearance.BorderSize = 0;
            this.btnPercent.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnPercent.ForeColor = System.Drawing.Color.White;
            this.btnPercent.Location = new System.Drawing.Point(4, 230);
            this.btnPercent.Margin = new System.Windows.Forms.Padding(0);
            this.btnPercent.Name = "btnPercent";
            this.btnPercent.Size = new System.Drawing.Size(85, 52);
            this.btnPercent.TabIndex = 5;
            this.btnPercent.Text = "%";
            this.btnPercent.TextColor = System.Drawing.Color.White;
            this.btnPercent.UseVisualStyleBackColor = false;
            this.btnPercent.Click += new System.EventHandler(this.btnmathop_click);
            // 
            // btndivision
            // 
            this.btndivision.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(50)))), ((int)(((byte)(50)))), ((int)(((byte)(50)))));
            this.btndivision.BackgroundColor = System.Drawing.Color.FromArgb(((int)(((byte)(50)))), ((int)(((byte)(50)))), ((int)(((byte)(50)))));
            this.btndivision.BorderRadios = 20;
            this.btndivision.Bordersize = 0;
            this.btndivision.FlatAppearance.BorderSize = 0;
            this.btndivision.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btndivision.Font = new System.Drawing.Font("Gadugi", 16F);
            this.btndivision.ForeColor = System.Drawing.Color.White;
            this.btndivision.Location = new System.Drawing.Point(274, 286);
            this.btndivision.Margin = new System.Windows.Forms.Padding(0);
            this.btndivision.Name = "btndivision";
            this.btndivision.Size = new System.Drawing.Size(85, 52);
            this.btndivision.TabIndex = 5;
            this.btndivision.Text = "÷";
            this.btndivision.TextColor = System.Drawing.Color.White;
            this.btndivision.UseVisualStyleBackColor = false;
            this.btndivision.Click += new System.EventHandler(this.btnOpration_Click);
            // 
            // btnsquer
            // 
            this.btnsquer.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(50)))), ((int)(((byte)(50)))), ((int)(((byte)(50)))));
            this.btnsquer.BackgroundColor = System.Drawing.Color.FromArgb(((int)(((byte)(50)))), ((int)(((byte)(50)))), ((int)(((byte)(50)))));
            this.btnsquer.BorderRadios = 20;
            this.btnsquer.Bordersize = 0;
            this.btnsquer.FlatAppearance.BorderSize = 0;
            this.btnsquer.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnsquer.ForeColor = System.Drawing.Color.White;
            this.btnsquer.Location = new System.Drawing.Point(184, 286);
            this.btnsquer.Margin = new System.Windows.Forms.Padding(0);
            this.btnsquer.Name = "btnsquer";
            this.btnsquer.Size = new System.Drawing.Size(85, 52);
            this.btnsquer.TabIndex = 5;
            this.btnsquer.Text = "√x";
            this.btnsquer.TextColor = System.Drawing.Color.White;
            this.btnsquer.UseVisualStyleBackColor = false;
            this.btnsquer.Click += new System.EventHandler(this.btnmathop_click);
            // 
            // btnX2
            // 
            this.btnX2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(50)))), ((int)(((byte)(50)))), ((int)(((byte)(50)))));
            this.btnX2.BackgroundColor = System.Drawing.Color.FromArgb(((int)(((byte)(50)))), ((int)(((byte)(50)))), ((int)(((byte)(50)))));
            this.btnX2.BorderRadios = 20;
            this.btnX2.Bordersize = 0;
            this.btnX2.FlatAppearance.BorderSize = 0;
            this.btnX2.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnX2.ForeColor = System.Drawing.Color.White;
            this.btnX2.Location = new System.Drawing.Point(94, 286);
            this.btnX2.Margin = new System.Windows.Forms.Padding(0);
            this.btnX2.Name = "btnX2";
            this.btnX2.Size = new System.Drawing.Size(85, 52);
            this.btnX2.TabIndex = 5;
            this.btnX2.Text = "^2";
            this.btnX2.TextColor = System.Drawing.Color.White;
            this.btnX2.UseVisualStyleBackColor = false;
            this.btnX2.Click += new System.EventHandler(this.btnmathop_click);
            // 
            // btn1x
            // 
            this.btn1x.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(50)))), ((int)(((byte)(50)))), ((int)(((byte)(50)))));
            this.btn1x.BackgroundColor = System.Drawing.Color.FromArgb(((int)(((byte)(50)))), ((int)(((byte)(50)))), ((int)(((byte)(50)))));
            this.btn1x.BorderRadios = 20;
            this.btn1x.Bordersize = 0;
            this.btn1x.FlatAppearance.BorderSize = 0;
            this.btn1x.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn1x.ForeColor = System.Drawing.Color.White;
            this.btn1x.Location = new System.Drawing.Point(4, 286);
            this.btn1x.Margin = new System.Windows.Forms.Padding(0);
            this.btn1x.Name = "btn1x";
            this.btn1x.Size = new System.Drawing.Size(85, 52);
            this.btn1x.TabIndex = 5;
            this.btn1x.Text = "1/";
            this.btn1x.TextColor = System.Drawing.Color.White;
            this.btn1x.UseVisualStyleBackColor = false;
            this.btn1x.Click += new System.EventHandler(this.btnmathop_click);
            // 
            // btnmultiply
            // 
            this.btnmultiply.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(50)))), ((int)(((byte)(50)))), ((int)(((byte)(50)))));
            this.btnmultiply.BackgroundColor = System.Drawing.Color.FromArgb(((int)(((byte)(50)))), ((int)(((byte)(50)))), ((int)(((byte)(50)))));
            this.btnmultiply.BorderRadios = 20;
            this.btnmultiply.Bordersize = 0;
            this.btnmultiply.FlatAppearance.BorderSize = 0;
            this.btnmultiply.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnmultiply.Font = new System.Drawing.Font("Gadugi", 16F);
            this.btnmultiply.ForeColor = System.Drawing.Color.White;
            this.btnmultiply.Location = new System.Drawing.Point(274, 342);
            this.btnmultiply.Margin = new System.Windows.Forms.Padding(0);
            this.btnmultiply.Name = "btnmultiply";
            this.btnmultiply.Size = new System.Drawing.Size(85, 52);
            this.btnmultiply.TabIndex = 5;
            this.btnmultiply.Text = "×";
            this.btnmultiply.TextColor = System.Drawing.Color.White;
            this.btnmultiply.UseVisualStyleBackColor = false;
            this.btnmultiply.Click += new System.EventHandler(this.btnOpration_Click);
            // 
            // btnsubtracation
            // 
            this.btnsubtracation.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(50)))), ((int)(((byte)(50)))), ((int)(((byte)(50)))));
            this.btnsubtracation.BackgroundColor = System.Drawing.Color.FromArgb(((int)(((byte)(50)))), ((int)(((byte)(50)))), ((int)(((byte)(50)))));
            this.btnsubtracation.BorderRadios = 20;
            this.btnsubtracation.Bordersize = 0;
            this.btnsubtracation.FlatAppearance.BorderSize = 0;
            this.btnsubtracation.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnsubtracation.Font = new System.Drawing.Font("Gadugi", 16F);
            this.btnsubtracation.ForeColor = System.Drawing.Color.White;
            this.btnsubtracation.Location = new System.Drawing.Point(274, 397);
            this.btnsubtracation.Margin = new System.Windows.Forms.Padding(0);
            this.btnsubtracation.Name = "btnsubtracation";
            this.btnsubtracation.Size = new System.Drawing.Size(85, 52);
            this.btnsubtracation.TabIndex = 5;
            this.btnsubtracation.Text = "-";
            this.btnsubtracation.TextColor = System.Drawing.Color.White;
            this.btnsubtracation.UseVisualStyleBackColor = false;
            this.btnsubtracation.Click += new System.EventHandler(this.btnOpration_Click);
            // 
            // btn9
            // 
            this.btn9.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(60)))), ((int)(((byte)(60)))), ((int)(((byte)(60)))));
            this.btn9.BackgroundColor = System.Drawing.Color.FromArgb(((int)(((byte)(60)))), ((int)(((byte)(60)))), ((int)(((byte)(60)))));
            this.btn9.BorderRadios = 20;
            this.btn9.Bordersize = 0;
            this.btn9.FlatAppearance.BorderSize = 0;
            this.btn9.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn9.Font = new System.Drawing.Font("Gadugi", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn9.ForeColor = System.Drawing.Color.White;
            this.btn9.Location = new System.Drawing.Point(184, 342);
            this.btn9.Margin = new System.Windows.Forms.Padding(0);
            this.btn9.Name = "btn9";
            this.btn9.Size = new System.Drawing.Size(85, 52);
            this.btn9.TabIndex = 5;
            this.btn9.Text = "9";
            this.btn9.TextColor = System.Drawing.Color.White;
            this.btn9.UseVisualStyleBackColor = false;
            this.btn9.Click += new System.EventHandler(this.BtnNum_Click);
            // 
            // btn6
            // 
            this.btn6.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(60)))), ((int)(((byte)(60)))), ((int)(((byte)(60)))));
            this.btn6.BackgroundColor = System.Drawing.Color.FromArgb(((int)(((byte)(60)))), ((int)(((byte)(60)))), ((int)(((byte)(60)))));
            this.btn6.BorderRadios = 20;
            this.btn6.Bordersize = 0;
            this.btn6.FlatAppearance.BorderSize = 0;
            this.btn6.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn6.Font = new System.Drawing.Font("Gadugi", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn6.ForeColor = System.Drawing.Color.White;
            this.btn6.Location = new System.Drawing.Point(184, 397);
            this.btn6.Margin = new System.Windows.Forms.Padding(0);
            this.btn6.Name = "btn6";
            this.btn6.Size = new System.Drawing.Size(85, 52);
            this.btn6.TabIndex = 5;
            this.btn6.Text = "6";
            this.btn6.TextColor = System.Drawing.Color.White;
            this.btn6.UseVisualStyleBackColor = false;
            this.btn6.Click += new System.EventHandler(this.BtnNum_Click);
            // 
            // btn8
            // 
            this.btn8.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(60)))), ((int)(((byte)(60)))), ((int)(((byte)(60)))));
            this.btn8.BackgroundColor = System.Drawing.Color.FromArgb(((int)(((byte)(60)))), ((int)(((byte)(60)))), ((int)(((byte)(60)))));
            this.btn8.BorderRadios = 20;
            this.btn8.Bordersize = 0;
            this.btn8.FlatAppearance.BorderSize = 0;
            this.btn8.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn8.Font = new System.Drawing.Font("Gadugi", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn8.ForeColor = System.Drawing.Color.White;
            this.btn8.Location = new System.Drawing.Point(94, 342);
            this.btn8.Margin = new System.Windows.Forms.Padding(0);
            this.btn8.Name = "btn8";
            this.btn8.Size = new System.Drawing.Size(85, 52);
            this.btn8.TabIndex = 5;
            this.btn8.Text = "8";
            this.btn8.TextColor = System.Drawing.Color.White;
            this.btn8.UseVisualStyleBackColor = false;
            this.btn8.Click += new System.EventHandler(this.BtnNum_Click);
            // 
            // btn5
            // 
            this.btn5.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(60)))), ((int)(((byte)(60)))), ((int)(((byte)(60)))));
            this.btn5.BackgroundColor = System.Drawing.Color.FromArgb(((int)(((byte)(60)))), ((int)(((byte)(60)))), ((int)(((byte)(60)))));
            this.btn5.BorderRadios = 20;
            this.btn5.Bordersize = 0;
            this.btn5.FlatAppearance.BorderSize = 0;
            this.btn5.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn5.Font = new System.Drawing.Font("Gadugi", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn5.ForeColor = System.Drawing.Color.White;
            this.btn5.Location = new System.Drawing.Point(94, 397);
            this.btn5.Margin = new System.Windows.Forms.Padding(0);
            this.btn5.Name = "btn5";
            this.btn5.Size = new System.Drawing.Size(85, 52);
            this.btn5.TabIndex = 5;
            this.btn5.Text = "5";
            this.btn5.TextColor = System.Drawing.Color.White;
            this.btn5.UseVisualStyleBackColor = false;
            this.btn5.Click += new System.EventHandler(this.BtnNum_Click);
            // 
            // btn7
            // 
            this.btn7.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(60)))), ((int)(((byte)(60)))), ((int)(((byte)(60)))));
            this.btn7.BackgroundColor = System.Drawing.Color.FromArgb(((int)(((byte)(60)))), ((int)(((byte)(60)))), ((int)(((byte)(60)))));
            this.btn7.BorderRadios = 20;
            this.btn7.Bordersize = 0;
            this.btn7.FlatAppearance.BorderSize = 0;
            this.btn7.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn7.Font = new System.Drawing.Font("Gadugi", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn7.ForeColor = System.Drawing.Color.White;
            this.btn7.Location = new System.Drawing.Point(4, 342);
            this.btn7.Margin = new System.Windows.Forms.Padding(0);
            this.btn7.Name = "btn7";
            this.btn7.Size = new System.Drawing.Size(85, 52);
            this.btn7.TabIndex = 5;
            this.btn7.Text = "7";
            this.btn7.TextColor = System.Drawing.Color.White;
            this.btn7.UseVisualStyleBackColor = false;
            this.btn7.Click += new System.EventHandler(this.BtnNum_Click);
            // 
            // btn4
            // 
            this.btn4.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(60)))), ((int)(((byte)(60)))), ((int)(((byte)(60)))));
            this.btn4.BackgroundColor = System.Drawing.Color.FromArgb(((int)(((byte)(60)))), ((int)(((byte)(60)))), ((int)(((byte)(60)))));
            this.btn4.BorderRadios = 20;
            this.btn4.Bordersize = 0;
            this.btn4.FlatAppearance.BorderSize = 0;
            this.btn4.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn4.Font = new System.Drawing.Font("Gadugi", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn4.ForeColor = System.Drawing.Color.White;
            this.btn4.Location = new System.Drawing.Point(4, 397);
            this.btn4.Margin = new System.Windows.Forms.Padding(0);
            this.btn4.Name = "btn4";
            this.btn4.Size = new System.Drawing.Size(85, 52);
            this.btn4.TabIndex = 5;
            this.btn4.Text = "4";
            this.btn4.TextColor = System.Drawing.Color.White;
            this.btn4.UseVisualStyleBackColor = false;
            this.btn4.Click += new System.EventHandler(this.BtnNum_Click);
            // 
            // btnadd
            // 
            this.btnadd.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(50)))), ((int)(((byte)(50)))), ((int)(((byte)(50)))));
            this.btnadd.BackgroundColor = System.Drawing.Color.FromArgb(((int)(((byte)(50)))), ((int)(((byte)(50)))), ((int)(((byte)(50)))));
            this.btnadd.BorderRadios = 20;
            this.btnadd.Bordersize = 0;
            this.btnadd.FlatAppearance.BorderSize = 0;
            this.btnadd.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnadd.Font = new System.Drawing.Font("Gadugi", 16F);
            this.btnadd.ForeColor = System.Drawing.Color.White;
            this.btnadd.Location = new System.Drawing.Point(274, 453);
            this.btnadd.Margin = new System.Windows.Forms.Padding(0);
            this.btnadd.Name = "btnadd";
            this.btnadd.Size = new System.Drawing.Size(85, 52);
            this.btnadd.TabIndex = 5;
            this.btnadd.Text = "+";
            this.btnadd.TextColor = System.Drawing.Color.White;
            this.btnadd.UseVisualStyleBackColor = false;
            this.btnadd.Click += new System.EventHandler(this.btnOpration_Click);
            // 
            // btnEquals
            // 
            this.btnEquals.BackColor = System.Drawing.SystemColors.MenuHighlight;
            this.btnEquals.BackgroundColor = System.Drawing.SystemColors.MenuHighlight;
            this.btnEquals.BorderRadios = 20;
            this.btnEquals.Bordersize = 0;
            this.btnEquals.FlatAppearance.BorderSize = 0;
            this.btnEquals.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnEquals.Font = new System.Drawing.Font("Gadugi", 16F);
            this.btnEquals.ForeColor = System.Drawing.Color.White;
            this.btnEquals.Location = new System.Drawing.Point(274, 509);
            this.btnEquals.Margin = new System.Windows.Forms.Padding(0);
            this.btnEquals.Name = "btnEquals";
            this.btnEquals.Size = new System.Drawing.Size(85, 52);
            this.btnEquals.TabIndex = 5;
            this.btnEquals.Text = "=";
            this.btnEquals.TextColor = System.Drawing.Color.White;
            this.btnEquals.UseVisualStyleBackColor = false;
            this.btnEquals.Click += new System.EventHandler(this.btnEquals_Click);
            // 
            // btn3
            // 
            this.btn3.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(60)))), ((int)(((byte)(60)))), ((int)(((byte)(60)))));
            this.btn3.BackgroundColor = System.Drawing.Color.FromArgb(((int)(((byte)(60)))), ((int)(((byte)(60)))), ((int)(((byte)(60)))));
            this.btn3.BorderRadios = 20;
            this.btn3.Bordersize = 0;
            this.btn3.FlatAppearance.BorderSize = 0;
            this.btn3.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn3.Font = new System.Drawing.Font("Gadugi", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn3.ForeColor = System.Drawing.Color.White;
            this.btn3.Location = new System.Drawing.Point(184, 453);
            this.btn3.Margin = new System.Windows.Forms.Padding(0);
            this.btn3.Name = "btn3";
            this.btn3.Size = new System.Drawing.Size(85, 52);
            this.btn3.TabIndex = 5;
            this.btn3.Text = "3";
            this.btn3.TextColor = System.Drawing.Color.White;
            this.btn3.UseVisualStyleBackColor = false;
            this.btn3.Click += new System.EventHandler(this.BtnNum_Click);
            // 
            // btndesimal
            // 
            this.btndesimal.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(60)))), ((int)(((byte)(60)))), ((int)(((byte)(60)))));
            this.btndesimal.BackgroundColor = System.Drawing.Color.FromArgb(((int)(((byte)(60)))), ((int)(((byte)(60)))), ((int)(((byte)(60)))));
            this.btndesimal.BorderRadios = 20;
            this.btndesimal.Bordersize = 0;
            this.btndesimal.FlatAppearance.BorderSize = 0;
            this.btndesimal.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btndesimal.Font = new System.Drawing.Font("Gadugi", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btndesimal.ForeColor = System.Drawing.Color.White;
            this.btndesimal.Location = new System.Drawing.Point(184, 509);
            this.btndesimal.Margin = new System.Windows.Forms.Padding(0);
            this.btndesimal.Name = "btndesimal";
            this.btndesimal.Size = new System.Drawing.Size(85, 52);
            this.btndesimal.TabIndex = 5;
            this.btndesimal.Text = ".";
            this.btndesimal.TextColor = System.Drawing.Color.White;
            this.btndesimal.UseVisualStyleBackColor = false;
            this.btndesimal.Click += new System.EventHandler(this.BtnNum_Click);
            // 
            // btn2
            // 
            this.btn2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(60)))), ((int)(((byte)(60)))), ((int)(((byte)(60)))));
            this.btn2.BackgroundColor = System.Drawing.Color.FromArgb(((int)(((byte)(60)))), ((int)(((byte)(60)))), ((int)(((byte)(60)))));
            this.btn2.BorderRadios = 20;
            this.btn2.Bordersize = 0;
            this.btn2.FlatAppearance.BorderSize = 0;
            this.btn2.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn2.Font = new System.Drawing.Font("Gadugi", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn2.ForeColor = System.Drawing.Color.White;
            this.btn2.Location = new System.Drawing.Point(94, 453);
            this.btn2.Margin = new System.Windows.Forms.Padding(0);
            this.btn2.Name = "btn2";
            this.btn2.Size = new System.Drawing.Size(85, 52);
            this.btn2.TabIndex = 5;
            this.btn2.Text = "2";
            this.btn2.TextColor = System.Drawing.Color.White;
            this.btn2.UseVisualStyleBackColor = false;
            this.btn2.Click += new System.EventHandler(this.BtnNum_Click);
            // 
            // btn0
            // 
            this.btn0.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(60)))), ((int)(((byte)(60)))), ((int)(((byte)(60)))));
            this.btn0.BackgroundColor = System.Drawing.Color.FromArgb(((int)(((byte)(60)))), ((int)(((byte)(60)))), ((int)(((byte)(60)))));
            this.btn0.BorderRadios = 20;
            this.btn0.Bordersize = 0;
            this.btn0.FlatAppearance.BorderSize = 0;
            this.btn0.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn0.Font = new System.Drawing.Font("Gadugi", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn0.ForeColor = System.Drawing.Color.White;
            this.btn0.Location = new System.Drawing.Point(94, 509);
            this.btn0.Margin = new System.Windows.Forms.Padding(0);
            this.btn0.Name = "btn0";
            this.btn0.Size = new System.Drawing.Size(85, 52);
            this.btn0.TabIndex = 5;
            this.btn0.Text = "0";
            this.btn0.TextColor = System.Drawing.Color.White;
            this.btn0.UseVisualStyleBackColor = false;
            this.btn0.Click += new System.EventHandler(this.BtnNum_Click);
            // 
            // btn1
            // 
            this.btn1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(60)))), ((int)(((byte)(60)))), ((int)(((byte)(60)))));
            this.btn1.BackgroundColor = System.Drawing.Color.FromArgb(((int)(((byte)(60)))), ((int)(((byte)(60)))), ((int)(((byte)(60)))));
            this.btn1.BorderRadios = 20;
            this.btn1.Bordersize = 0;
            this.btn1.FlatAppearance.BorderSize = 0;
            this.btn1.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn1.Font = new System.Drawing.Font("Gadugi", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn1.ForeColor = System.Drawing.Color.White;
            this.btn1.Location = new System.Drawing.Point(4, 453);
            this.btn1.Margin = new System.Windows.Forms.Padding(0);
            this.btn1.Name = "btn1";
            this.btn1.Size = new System.Drawing.Size(85, 52);
            this.btn1.TabIndex = 5;
            this.btn1.Text = "1";
            this.btn1.TextColor = System.Drawing.Color.White;
            this.btn1.UseVisualStyleBackColor = false;
            this.btn1.Click += new System.EventHandler(this.BtnNum_Click);
            // 
            // btnPm
            // 
            this.btnPm.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(60)))), ((int)(((byte)(60)))), ((int)(((byte)(60)))));
            this.btnPm.BackgroundColor = System.Drawing.Color.FromArgb(((int)(((byte)(60)))), ((int)(((byte)(60)))), ((int)(((byte)(60)))));
            this.btnPm.BorderRadios = 20;
            this.btnPm.Bordersize = 0;
            this.btnPm.FlatAppearance.BorderSize = 0;
            this.btnPm.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnPm.Font = new System.Drawing.Font("Gadugi", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnPm.ForeColor = System.Drawing.Color.White;
            this.btnPm.Location = new System.Drawing.Point(4, 509);
            this.btnPm.Margin = new System.Windows.Forms.Padding(0);
            this.btnPm.Name = "btnPm";
            this.btnPm.Size = new System.Drawing.Size(85, 52);
            this.btnPm.TabIndex = 5;
            this.btnPm.Text = "±";
            this.btnPm.TextColor = System.Drawing.Color.White;
            this.btnPm.UseVisualStyleBackColor = false;
            this.btnPm.Click += new System.EventHandler(this.btnmathop_click);
            // 
            // Form1
            // 
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.None;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(32)))), ((int)(((byte)(32)))), ((int)(((byte)(32)))));
            this.ClientSize = new System.Drawing.Size(368, 570);
            this.Controls.Add(this.ctlBut7);
            this.Controls.Add(this.ctlBut6);
            this.Controls.Add(this.ctlBut5);
            this.Controls.Add(this.ctlBut4);
            this.Controls.Add(this.ctlBut3);
            this.Controls.Add(this.ctlBut2);
            this.Controls.Add(this.btnPm);
            this.Controls.Add(this.btn4);
            this.Controls.Add(this.btn1x);
            this.Controls.Add(this.btn1);
            this.Controls.Add(this.btn7);
            this.Controls.Add(this.btnPercent);
            this.Controls.Add(this.btn0);
            this.Controls.Add(this.btn5);
            this.Controls.Add(this.btnX2);
            this.Controls.Add(this.btn2);
            this.Controls.Add(this.btn8);
            this.Controls.Add(this.btnCE);
            this.Controls.Add(this.btndesimal);
            this.Controls.Add(this.btn6);
            this.Controls.Add(this.btn3);
            this.Controls.Add(this.btn9);
            this.Controls.Add(this.btnsquer);
            this.Controls.Add(this.btnEquals);
            this.Controls.Add(this.btnsubtracation);
            this.Controls.Add(this.btnadd);
            this.Controls.Add(this.btnC);
            this.Controls.Add(this.btnmultiply);
            this.Controls.Add(this.btndivision);
            this.Controls.Add(this.btnbackspace);
            this.Controls.Add(this.TxtDisplay1);
            this.Controls.Add(this.TxtDispaly2);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.PanelHistory);
            this.Controls.Add(this.PnlTitle);
            this.Font = new System.Drawing.Font("Gadugi", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ForeColor = System.Drawing.Color.White;
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "Form1";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Form1";
            this.PnlTitle.ResumeLayout(false);
            this.PanelHistory.ResumeLayout(false);
            this.panel1.ResumeLayout(false);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Panel PnlTitle;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Button btnExit;
        private System.Windows.Forms.Panel PanelHistory;
        private System.Windows.Forms.RichTextBox RtBoxDisplayHistory;
        private System.Windows.Forms.Button BtnClearHis;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Button BtnMenu;
        private System.Windows.Forms.Button btnHistory;
        private System.Windows.Forms.TextBox TxtDispaly2;
        private System.Windows.Forms.TextBox TxtDisplay1;
        private CtlElipse.CtlEllipseControle EllipseForm;
        private CtlButton.CtlBut ctlBut7;
        private CtlButton.CtlBut ctlBut6;
        private CtlButton.CtlBut ctlBut5;
        private CtlButton.CtlBut ctlBut4;
        private CtlButton.CtlBut ctlBut3;
        private CtlButton.CtlBut ctlBut2;
        private CtlButton.CtlBut btnbackspace;
        private CtlButton.CtlBut btnPm;
        private CtlButton.CtlBut btn4;
        private CtlButton.CtlBut btn1x;
        private CtlButton.CtlBut btn1;
        private CtlButton.CtlBut btn7;
        private CtlButton.CtlBut btnPercent;
        private CtlButton.CtlBut btn0;
        private CtlButton.CtlBut btn5;
        private CtlButton.CtlBut btnX2;
        private CtlButton.CtlBut btn2;
        private CtlButton.CtlBut btn8;
        private CtlButton.CtlBut btnCE;
        private CtlButton.CtlBut btndesimal;
        private CtlButton.CtlBut btn6;
        private CtlButton.CtlBut btn3;
        private CtlButton.CtlBut btn9;
        private CtlButton.CtlBut btnsquer;
        private CtlButton.CtlBut btnEquals;
        private CtlButton.CtlBut btnsubtracation;
        private CtlButton.CtlBut btnadd;
        private CtlButton.CtlBut btnC;
        private CtlButton.CtlBut btnmultiply;
        private CtlButton.CtlBut btndivision;
    }
}

